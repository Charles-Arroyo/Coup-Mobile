create definer = `mariadb.sys`@localhost view x$statements_with_runtimes_in_95th_percentile as
select `stmts`.`DIGEST_TEXT`                                                                AS `query`,
       `stmts`.`SCHEMA_NAME`                                                                AS `db`,
       if(`stmts`.`SUM_NO_GOOD_INDEX_USED` > 0 or `stmts`.`SUM_NO_INDEX_USED` > 0, '*', '') AS `full_scan`,
       `stmts`.`COUNT_STAR`                                                                 AS `exec_count`,
       `stmts`.`SUM_ERRORS`                                                                 AS `err_count`,
       `stmts`.`SUM_WARNINGS`                                                               AS `warn_count`,
       `stmts`.`SUM_TIMER_WAIT`                                                             AS `total_latency`,
       `stmts`.`MAX_TIMER_WAIT`                                                             AS `max_latency`,
       `stmts`.`AVG_TIMER_WAIT`                                                             AS `avg_latency`,
       `stmts`.`SUM_ROWS_SENT`                                                              AS `rows_sent`,
       round(ifnull(`stmts`.`SUM_ROWS_SENT` / nullif(`stmts`.`COUNT_STAR`, 0), 0), 0)       AS `rows_sent_avg`,
       `stmts`.`SUM_ROWS_EXAMINED`                                                          AS `rows_examined`,
       round(ifnull(`stmts`.`SUM_ROWS_EXAMINED` / nullif(`stmts`.`COUNT_STAR`, 0), 0), 0)   AS `rows_examined_avg`,
       `stmts`.`FIRST_SEEN`                                                                 AS `first_seen`,
       `stmts`.`LAST_SEEN`                                                                  AS `last_seen`,
       `stmts`.`DIGEST`                                                                     AS `digest`
from (`performance_schema`.`events_statements_summary_by_digest` `stmts` join `sys`.`x$ps_digest_95th_percentile_by_avg_us` `top_percentile`
      on (round(`stmts`.`AVG_TIMER_WAIT` / 1000000, 0) >= `top_percentile`.`avg_us`))
order by `stmts`.`AVG_TIMER_WAIT` desc;

-- comment on column x$statements_with_runtimes_in_95th_percentile.query not supported: The unhashed form of the digest.

-- comment on column x$statements_with_runtimes_in_95th_percentile.db not supported: Database name. Records are summarised together with DIGEST.

-- comment on column x$statements_with_runtimes_in_95th_percentile.exec_count not supported: Number of summarized events

-- comment on column x$statements_with_runtimes_in_95th_percentile.err_count not supported: Sum of the ERRORS column in the events_statements_current table.

-- comment on column x$statements_with_runtimes_in_95th_percentile.warn_count not supported: Sum of the WARNINGS column in the events_statements_current table.

-- comment on column x$statements_with_runtimes_in_95th_percentile.total_latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$statements_with_runtimes_in_95th_percentile.max_latency not supported: Maximum wait time of the summarized events that are timed.

-- comment on column x$statements_with_runtimes_in_95th_percentile.avg_latency not supported: Average wait time of the summarized events that are timed.

-- comment on column x$statements_with_runtimes_in_95th_percentile.rows_sent not supported: Sum of the ROWS_SENT column in the events_statements_current table.

-- comment on column x$statements_with_runtimes_in_95th_percentile.rows_examined not supported: Sum of the ROWS_EXAMINED column in the events_statements_current table.

-- comment on column x$statements_with_runtimes_in_95th_percentile.first_seen not supported: Time at which the digest was first seen.

-- comment on column x$statements_with_runtimes_in_95th_percentile.last_seen not supported: Time at which the digest was most recently seen.

-- comment on column x$statements_with_runtimes_in_95th_percentile.digest not supported: Performance Schema digest. Records are summarised together with SCHEMA NAME.

